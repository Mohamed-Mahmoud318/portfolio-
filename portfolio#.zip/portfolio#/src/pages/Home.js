import React from "react";

function Home() {
  return (
    <div className="home-page">
      <h1> Mohamed Mahmoud</h1>
      <p>Back-End Developer | .NET | SQL Server</p>
    </div>
  );
}

export default Home;
