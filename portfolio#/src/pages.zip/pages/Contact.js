import React from "react";

function Contact() {
  return (
    <div>
      <h2> Contact me </h2>
      <p>You can Contact me by Email: <strong>mohamedmahmoudabdelhafeez109@gmail.com</strong></p>
    </div>
  );
}

export default Contact;
