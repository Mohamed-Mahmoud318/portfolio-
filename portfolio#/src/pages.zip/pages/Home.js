import React from "react";

function Home() {
  return (
    <div>
      <h1> Mohamed Mahmoud</h1>
      <p>Back-End Developer | .NET | SQL Server</p>
    </div>
  );
}

export default Home;
